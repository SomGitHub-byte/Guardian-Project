# guardian_app.py
import streamlit as st
from groq import Groq
from dotenv import load_dotenv
import os

# Load .env (if present)
load_dotenv()

st.set_page_config(page_title="Guardian AI", page_icon="🛡️", layout="wide")

st.title("🛡️ Guardian AI")
st.write("Ask anything and get instant insights powered by Groq.")

# --- Get or request GROQ API key ---
groq_key = os.getenv("GROQ_API_KEY")

with st.sidebar:
    st.header("Settings")
    st.write(
        "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"
    )
    # only show input if env var not found
    if not groq_key:
        groq_input = st.text_input("GROQ API Key", type="password", placeholder="gsk_...")
        if groq_input:
            # set it for this process
            os.environ["GROQ_API_KEY"] = groq_input
            groq_key = groq_input
            st.success("API key set for this session.")
    else:
        st.write("GROQ_API_KEY loaded from environment.")

# If still no key, stop and prompt user
if not groq_key:
    st.warning("No GROQ API key found. Enter it in the sidebar to continue.")
    st.stop()

# --- Initialize Groq client ---
try:
    client = Groq(api_key=groq_key)
except Exception as e:
    st.error(f"Failed to initialize Groq client: {e}")
    st.stop()

# Guardian AI response function
def guardian_response(user_input: str) -> str:
    try:
        completion = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {"role": "system", "content": "You are Guardian AI, a helpful and intelligent assistant."},
                {"role": "user", "content": user_input}
            ],
            temperature=0.0,
            max_tokens=800
        )
        # Use dot-notation to access the returned message object
        return completion.choices[0].message.content
    except Exception as e:
        # surface a clear error to the user
        return f"⚠️ Error: {str(e)}"

# --- Chat state ---
if "messages" not in st.session_state:
    st.session_state.messages = []

# Show chat history
for msg in st.session_state.messages:
    role = msg.get("role", "assistant")
    content = msg.get("content", "")
    if role == "user":
        st.chat_message("user").write(content)
    else:
        st.chat_message("assistant").write(content)

# User input
user_query = st.chat_input("Ask Guardian...")

if user_query:
    # Save and display user message
    st.session_state.messages.append({"role": "user", "content": user_query})
    st.chat_message("user").write(user_query)

    # Get answer from Groq
    answer = guardian_response(user_query)

    # Save and display assistant reply
    st.session_state.messages.append({"role": "assistant", "content": answer})
    st.chat_message("assistant").write(answer)

# Footer info
st.sidebar.markdown("---")
st.sidebar.markdown(
    "Get a free Groq key at https://console.groq.com\n\n"
    "Tip: For production, store your key in environment variables or a secrets manager."
)
