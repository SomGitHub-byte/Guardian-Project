from groq import Groq
from dotenv import load_dotenv
import os

load_dotenv()   # loads GROQ_API_KEY from .env

client = Groq(api_key=os.getenv("GROQ_API_KEY"))


def guardian(query):
    """
    A simple function that sends user input to Groq LLM
    and returns the model's response.
    """

    try:
        completion = client.chat.completions.create(
            model="mixtral-8x7b-32768",   # Free + Fast
            messages=[
                {"role": "system", "content": "You are Guardian AI. Be helpful and concise."},
                {"role": "user", "content": query}
            ],
            temperature=0.5
        )

        return completion.choices[0].message.content

    except Exception as e:
        return f"Error: {str(e)}"


if __name__ == "__main__":
    print("Guardian AI is running...\n")

    while True:
        user_input = input("You: ")

        if user_input.lower() in ["exit", "quit"]:
            print("Guardian stopped.")
            break

        response = guardian(user_input)
        print("Guardian:", response)
